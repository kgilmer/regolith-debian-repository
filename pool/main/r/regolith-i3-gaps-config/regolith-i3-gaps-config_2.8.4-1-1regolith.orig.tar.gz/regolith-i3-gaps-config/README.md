# regolith-i3-gaps-config

This repo is for Regolith-specific configuration for i3-gaps.  