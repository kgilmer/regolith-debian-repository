// vim:ts=4:sw=4:expandtab
#pragma once

void extensions_init(void);
